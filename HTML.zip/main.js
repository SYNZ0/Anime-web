// Highlight the active page in the navigation
document.addEventListener('DOMContentLoaded', () => {
    const navLinks = document.querySelectorAll('nav a');
    const currentUrl = window.location.href;

    navLinks.forEach(link => {
        if (link.href === currentUrl) {
            link.classList.add('active');
        }
    });
});

// Simple Image Modal for Wallpapers (optional)
const images = document.querySelectorAll('.wallpaper-item img');
const modal = document.createElement('div');
const modalImg = document.createElement('img');

// Styling for the modal
modal.style.position = 'fixed';
modal.style.top = '50%';
modal.style.left = '50%';
modal.style.transform = 'translate(-50%, -50%)';
modal.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
modal.style.display = 'none';
modal.style.zIndex = '1000';
modal.appendChild(modalImg);
document.body.appendChild(modal);

// Event listener for clicking an image
images.forEach(img => {
    img.addEventListener('click', () => {
        modalImg.src = img.src;
        modal.style.display = 'block';
    });
});

// Close modal when clicked outside the image
modal.addEventListener('click', () => {
    modal.style.display = 'none';
});